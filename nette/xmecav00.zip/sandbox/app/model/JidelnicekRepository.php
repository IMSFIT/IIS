<?php
namespace Todo;
use Nette;

/**
 * Tabulka jidelnicek
 */
class JidelnicekRepository extends Repository
{

}

