<?php

namespace Todo;
use Nette;

/**
 * Tabulka jidla
 */
class JidloRepository extends Repository
{
}