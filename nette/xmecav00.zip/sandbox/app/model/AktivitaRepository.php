<?php

namespace Todo;
use Nette;

/**
 * Tabulka jidla
 */
class AktivitaRepository extends Repository
{
}