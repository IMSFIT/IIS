<?php
namespace Todo;
use Nette;

/**
 * Tabulka typ_diety
 */
class Typ_DietyRepository extends Repository
{
}