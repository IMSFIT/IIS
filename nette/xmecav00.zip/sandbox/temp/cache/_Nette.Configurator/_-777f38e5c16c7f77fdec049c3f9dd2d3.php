<?php //netteCache[01]009697a:2:{s:4:"time";s:21:"0.32383900 1383091770";s:9:"callbacks";a:45:{i:0;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:100:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app\config\config.neon";i:2;i:1375920988;}i:1;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app\config\config.local.neon";i:2;i:1375920988;}i:2;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:123:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Config\Extensions\PhpExtension.php";i:2;i:1375921086;}i:3;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:129:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Config\Extensions\ConstantsExtension.php";i:2;i:1375921086;}i:4;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:125:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Config\Extensions\NetteExtension.php";i:2;i:1375921086;}i:5;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\common\Object.php";i:2;i:1375921086;}i:6;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:118:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Caching\Storages\IJournal.php";i:2;i:1375921086;}i:7;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:121:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Caching\Storages\FileJournal.php";i:2;i:1375921086;}i:8;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:109:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Caching\IStorage.php";i:2;i:1375921086;}i:9;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:121:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Caching\Storages\FileStorage.php";i:2;i:1375921086;}i:10;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:112:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\RequestFactory.php";i:2;i:1375921086;}i:11;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\IRequest.php";i:2;i:1375921086;}i:12;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\Request.php";i:2;i:1375921086;}i:13;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:107:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\IResponse.php";i:2;i:1375921086;}i:14;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\Response.php";i:2;i:1375921086;}i:15;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\Context.php";i:2;i:1375921086;}i:16;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\Session.php";i:2;i:1375921086;}i:17;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:114:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Security\IUserStorage.php";i:2;i:1375921086;}i:18;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:109:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Http\UserStorage.php";i:2;i:1375921086;}i:19;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Security\User.php";i:2;i:1375921086;}i:20;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:116:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Application\Application.php";i:2;i:1375921086;}i:21;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:122:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Application\IPresenterFactory.php";i:2;i:1375921086;}i:22;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:121:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Application\PresenterFactory.php";i:2;i:1375921086;}i:23;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:112:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Application\IRouter.php";i:2;i:1375921086;}i:24;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Mail\IMailer.php";i:2;i:1375921086;}i:25;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:112:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Mail\SendmailMailer.php";i:2;i:1375921086;}i:26;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:110:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\DI\NestedAccessor.php";i:2;i:1375921086;}i:27;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:112:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Database\Connection.php";i:2;i:1375921086;}i:28;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app\router\RouterFactory.php";i:2;i:1375920988;}i:29;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:116:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Security\IAuthenticator.php";i:2;i:1375921086;}i:30;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app\model\Authenticator.php";i:2;i:1375920988;}i:31;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:115:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\common\FreezableObject.php";i:2;i:1375921086;}i:32;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:110:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\common\IFreezable.php";i:2;i:1375921086;}i:33;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\DI\IContainer.php";i:2;i:1375921086;}i:34;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\DI\Container.php";i:2;i:1375921086;}i:35;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:129:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Application\Diagnostics\RoutingPanel.php";i:2;i:1375921086;}i:36;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:103:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Forms\Form.php";i:2;i:1375921086;}i:37;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:108:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\common\Callback.php";i:2;i:1375921086;}i:38;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:106:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Caching\Cache.php";i:2;i:1375921086;}i:39;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:133:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Database\Reflection\DiscoveredReflection.php";i:2;i:1375921086;}i:40;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Latte\Engine.php";i:2;i:1375921086;}i:41;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:105:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Mail\Message.php";i:2;i:1375921086;}i:42;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:116:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Templating\FileTemplate.php";i:2;i:1375921086;}i:43;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:112:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Templating\Template.php";i:2;i:1375921086;}i:44;a:3:{i:0;a:2:{i:0;s:19:"Nette\Caching\Cache";i:1;s:9:"checkFile";}i:1;s:123:"C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\libs\Nette\Security\Diagnostics\UserPanel.php";i:2;i:1375921086;}}}?><?php
// source: C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app/config/config.neon development
// source: C:\Program Files (x86)\EasyPHP-DevServer-13.1VC11\data\localweb\nette\sandbox\app/config/config.local.neon 

/**
 * @property Nette\Application\Application $application
 * @property Authenticator $authenticator
 * @property Nette\Caching\Storages\FileStorage $cacheStorage
 * @property Nette\DI\NestedAccessor $constants
 * @property Nette\DI\Container $container
 * @property Nette\Http\Request $httpRequest
 * @property Nette\Http\Response $httpResponse
 * @property SystemContainer_nette $nette
 * @property Nette\DI\NestedAccessor $php
 * @property Nette\Application\IRouter $router
 * @property RouterFactory $routerFactory
 * @property Nette\Http\Session $session
 * @property Nette\Security\User $user
 */
class SystemContainer extends Nette\DI\Container
{

	public $classes = array(
		'nette\\object' => FALSE, //: nette.cacheJournal, cacheStorage, nette.httpRequestFactory, httpRequest, httpResponse, nette.httpContext, session, nette.userStorage, user, application, nette.presenterFactory, nette.mailer, nette.database, authenticator, container,
		'nette\\caching\\storages\\ijournal' => 'nette.cacheJournal',
		'nette\\caching\\storages\\filejournal' => 'nette.cacheJournal',
		'nette\\caching\\istorage' => 'cacheStorage',
		'nette\\caching\\storages\\filestorage' => 'cacheStorage',
		'nette\\http\\requestfactory' => 'nette.httpRequestFactory',
		'nette\\http\\irequest' => 'httpRequest',
		'nette\\http\\request' => 'httpRequest',
		'nette\\http\\iresponse' => 'httpResponse',
		'nette\\http\\response' => 'httpResponse',
		'nette\\http\\context' => 'nette.httpContext',
		'nette\\http\\session' => 'session',
		'nette\\security\\iuserstorage' => 'nette.userStorage',
		'nette\\http\\userstorage' => 'nette.userStorage',
		'nette\\security\\user' => 'user',
		'nette\\application\\application' => 'application',
		'nette\\application\\ipresenterfactory' => 'nette.presenterFactory',
		'nette\\application\\presenterfactory' => 'nette.presenterFactory',
		'nette\\application\\irouter' => 'router',
		'nette\\mail\\imailer' => 'nette.mailer',
		'nette\\mail\\sendmailmailer' => 'nette.mailer',
		'nette\\di\\nestedaccessor' => 'nette.database',
		'pdo' => 'nette.database.default',
		'nette\\database\\connection' => 'nette.database.default',
		'routerfactory' => 'routerFactory',
		'nette\\security\\iauthenticator' => 'authenticator',
		'authenticator' => 'authenticator',
		'nette\\freezableobject' => 'container',
		'nette\\ifreezable' => 'container',
		'nette\\di\\icontainer' => 'container',
		'nette\\di\\container' => 'container',
	);

	public $meta = array();


	public function __construct()
	{
		parent::__construct(array(
			'appDir' => 'C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app',
			'wwwDir' => 'C:/Program Files (x86)/EasyPHP-DevServer-13.1VC11/data/localweb/nette/sandbox/www',
			'debugMode' => TRUE,
			'productionMode' => FALSE,
			'environment' => 'development',
			'consoleMode' => FALSE,
			'container' => array(
				'class' => 'SystemContainer',
				'parent' => 'Nette\\DI\\Container',
			),
			'tempDir' => 'C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app/../temp',
		));
	}


	/**
	 * @return Nette\Application\Application
	 */
	protected function createServiceApplication()
	{
		$service = new Nette\Application\Application($this->getService('nette.presenterFactory'), $this->getService('router'), $this->getService('httpRequest'), $this->getService('httpResponse'));
		$service->catchExceptions = FALSE;
		$service->errorPresenter = 'Error';
		Nette\Application\Diagnostics\RoutingPanel::initializePanel($service);
		Nette\Diagnostics\Debugger::$bar->addPanel(new Nette\Application\Diagnostics\RoutingPanel($this->getService('router'), $this->getService('httpRequest')));
		return $service;
	}


	/**
	 * @return Authenticator
	 */
	protected function createServiceAuthenticator()
	{
		$service = new Authenticator($this->getService('nette.database.default'));
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\FileStorage
	 */
	protected function createServiceCacheStorage()
	{
		$service = new Nette\Caching\Storages\FileStorage('C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app/../temp/cache', $this->getService('nette.cacheJournal'));
		return $service;
	}


	/**
	 * @return Nette\DI\NestedAccessor
	 */
	protected function createServiceConstants()
	{
		$service = new Nette\DI\NestedAccessor($this, 'constants');
		return $service;
	}


	/**
	 * @return Nette\DI\Container
	 */
	protected function createServiceContainer()
	{
		return $this;
	}


	/**
	 * @return Nette\Http\Request
	 */
	protected function createServiceHttpRequest()
	{
		$service = $this->getService('nette.httpRequestFactory')->createHttpRequest();
		if (!$service instanceof Nette\Http\Request) {
			throw new Nette\UnexpectedValueException('Unable to create service \'httpRequest\', value returned by factory is not Nette\\Http\\Request type.');
		}
		return $service;
	}


	/**
	 * @return Nette\Http\Response
	 */
	protected function createServiceHttpResponse()
	{
		$service = new Nette\Http\Response;
		return $service;
	}


	/**
	 * @return Nette\DI\NestedAccessor
	 */
	protected function createServiceNette()
	{
		$service = new Nette\DI\NestedAccessor($this, 'nette');
		return $service;
	}


	/**
	 * @return Nette\Forms\Form
	 */
	public function createNette__basicForm()
	{
		$service = new Nette\Forms\Form;
		return $service;
	}


	/**
	 * @return Nette\Callback
	 */
	protected function createServiceNette__basicFormFactory()
	{
		$service = new Nette\Callback($this, 'createNette__basicForm');
		return $service;
	}


	/**
	 * @return Nette\Caching\Cache
	 */
	public function createNette__cache($namespace = NULL)
	{
		$service = new Nette\Caching\Cache($this->getService('cacheStorage'), $namespace);
		return $service;
	}


	/**
	 * @return Nette\Callback
	 */
	protected function createServiceNette__cacheFactory()
	{
		$service = new Nette\Callback($this, 'createNette__cache');
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\FileJournal
	 */
	protected function createServiceNette__cacheJournal()
	{
		$service = new Nette\Caching\Storages\FileJournal('C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app/../temp');
		return $service;
	}


	/**
	 * @return Nette\DI\NestedAccessor
	 */
	protected function createServiceNette__database()
	{
		$service = new Nette\DI\NestedAccessor($this, 'nette.database');
		return $service;
	}


	/**
	 * @return Nette\Database\Connection
	 */
	protected function createServiceNette__database__default()
	{
		$service = new Nette\Database\Connection('mysql:host=localhost;dbname=test', NULL, NULL, NULL);
		$service->setCacheStorage($this->getService('cacheStorage'));
		Nette\Diagnostics\Debugger::$blueScreen->addPanel('Nette\\Database\\Diagnostics\\ConnectionPanel::renderException');
		$service->setDatabaseReflection(new Nette\Database\Reflection\DiscoveredReflection($this->getService('cacheStorage')));
		$service->onQuery[] = array(
			$this->getService('nette.database.defaultConnectionPanel'),
			'logQuery',
		);
		return $service;
	}


	/**
	 * @return Nette\Database\Diagnostics\ConnectionPanel
	 */
	protected function createServiceNette__database__defaultConnectionPanel()
	{
		$service = new Nette\Database\Diagnostics\ConnectionPanel;
		$service->explain = TRUE;
		$service->name = 'default';
		Nette\Diagnostics\Debugger::$bar->addPanel($service);
		return $service;
	}


	/**
	 * @return Nette\Http\Context
	 */
	protected function createServiceNette__httpContext()
	{
		$service = new Nette\Http\Context($this->getService('httpRequest'), $this->getService('httpResponse'));
		return $service;
	}


	/**
	 * @return Nette\Http\RequestFactory
	 */
	protected function createServiceNette__httpRequestFactory()
	{
		$service = new Nette\Http\RequestFactory;
		$service->setEncoding('UTF-8');
		return $service;
	}


	/**
	 * @return Nette\Latte\Engine
	 */
	public function createNette__latte()
	{
		$service = new Nette\Latte\Engine;
		return $service;
	}


	/**
	 * @return Nette\Callback
	 */
	protected function createServiceNette__latteFactory()
	{
		$service = new Nette\Callback($this, 'createNette__latte');
		return $service;
	}


	/**
	 * @return Nette\Mail\Message
	 */
	public function createNette__mail()
	{
		$service = new Nette\Mail\Message;
		$service->setMailer($this->getService('nette.mailer'));
		return $service;
	}


	/**
	 * @return Nette\Callback
	 */
	protected function createServiceNette__mailFactory()
	{
		$service = new Nette\Callback($this, 'createNette__mail');
		return $service;
	}


	/**
	 * @return Nette\Mail\SendmailMailer
	 */
	protected function createServiceNette__mailer()
	{
		$service = new Nette\Mail\SendmailMailer;
		return $service;
	}


	/**
	 * @return Nette\Application\PresenterFactory
	 */
	protected function createServiceNette__presenterFactory()
	{
		$service = new Nette\Application\PresenterFactory('C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app', $this);
		return $service;
	}


	/**
	 * @return Nette\Templating\FileTemplate
	 */
	public function createNette__template()
	{
		$service = new Nette\Templating\FileTemplate;
		$service->registerFilter($this->createNette__latte());
		$service->registerHelperLoader('Nette\\Templating\\Helpers::loader');
		return $service;
	}


	/**
	 * @return Nette\Caching\Storages\PhpFileStorage
	 */
	protected function createServiceNette__templateCacheStorage()
	{
		$service = new Nette\Caching\Storages\PhpFileStorage('C:\\Program Files (x86)\\EasyPHP-DevServer-13.1VC11\\data\\localweb\\nette\\sandbox\\app/../temp/cache', $this->getService('nette.cacheJournal'));
		return $service;
	}


	/**
	 * @return Nette\Callback
	 */
	protected function createServiceNette__templateFactory()
	{
		$service = new Nette\Callback($this, 'createNette__template');
		return $service;
	}


	/**
	 * @return Nette\Http\UserStorage
	 */
	protected function createServiceNette__userStorage()
	{
		$service = new Nette\Http\UserStorage($this->getService('session'));
		return $service;
	}


	/**
	 * @return Nette\DI\NestedAccessor
	 */
	protected function createServicePhp()
	{
		$service = new Nette\DI\NestedAccessor($this, 'php');
		return $service;
	}


	/**
	 * @return Nette\Application\IRouter
	 */
	protected function createServiceRouter()
	{
		$service = $this->getService('routerFactory')->createRouter();
		if (!$service instanceof Nette\Application\IRouter) {
			throw new Nette\UnexpectedValueException('Unable to create service \'router\', value returned by factory is not Nette\\Application\\IRouter type.');
		}
		return $service;
	}


	/**
	 * @return RouterFactory
	 */
	protected function createServiceRouterFactory()
	{
		$service = new RouterFactory;
		return $service;
	}


	/**
	 * @return Nette\Http\Session
	 */
	protected function createServiceSession()
	{
		$service = new Nette\Http\Session($this->getService('httpRequest'), $this->getService('httpResponse'));
		$service->setExpiration('14 days');
		return $service;
	}


	/**
	 * @return Nette\Security\User
	 */
	protected function createServiceUser()
	{
		$service = new Nette\Security\User($this->getService('nette.userStorage'), $this);
		Nette\Diagnostics\Debugger::$bar->addPanel(new Nette\Security\Diagnostics\UserPanel($service));
		return $service;
	}


	public function initialize()
	{
		date_default_timezone_set('Europe/Prague');
		Nette\Caching\Storages\FileStorage::$useDirectories = TRUE;

		$this->getService("session")->exists() && $this->getService("session")->start();
		header('X-Frame-Options: SAMEORIGIN');
	}

}



/**
 * @property Nette\Database\Connection $default
 * @property Nette\Database\Diagnostics\ConnectionPanel $defaultConnectionPanel
 */
class SystemContainer_nette_database
{



}



/**
 * @method Nette\Forms\Form createBasicForm()
 * @property Nette\Callback $basicFormFactory
 * @method Nette\Caching\Cache createCache()
 * @property Nette\Callback $cacheFactory
 * @property Nette\Caching\Storages\FileJournal $cacheJournal
 * @property SystemContainer_nette_database $database
 * @property Nette\Http\Context $httpContext
 * @method Nette\Latte\Engine createLatte()
 * @property Nette\Callback $latteFactory
 * @method Nette\Mail\Message createMail()
 * @property Nette\Callback $mailFactory
 * @property Nette\Mail\SendmailMailer $mailer
 * @property Nette\Application\PresenterFactory $presenterFactory
 * @method Nette\Templating\FileTemplate createTemplate()
 * @property Nette\Caching\Storages\PhpFileStorage $templateCacheStorage
 * @property Nette\Callback $templateFactory
 * @property Nette\Http\UserStorage $userStorage
 */
class SystemContainer_nette
{



}
